# jscompress.com [![Build Status](https://travis-ci.org/circlecell/jscompress.com.svg?branch=master)](https://travis-ci.org/circlecell/jscompress.com) [![devDependency Status](https://img.shields.io/david/dev/circlecell/jscompress.com.svg)](https://david-dm.org/circlecell/jscompress.com#info=devDependencies) [![Dependency Status](https://img.shields.io/david/circlecell/jscompress.com.svg)](https://david-dm.org/circlecell/jscompress.com)


This is the second version of [jscompress.com](http://jscompress.com): it's modular, has more features (eg drag'n'drop) and works 100% on client-side.

Check out [CONTRIBUTING.md](CONTRIBUTING.md) before making pull request.
